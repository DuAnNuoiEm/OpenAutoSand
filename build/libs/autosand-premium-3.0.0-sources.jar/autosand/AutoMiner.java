package autosand;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Set;
import java.util.function.Predicate;
import net.minecraft.class_1268;
import net.minecraft.class_1542;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2338.class_2339;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_238;
import net.minecraft.class_239.class_240;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3486;
import net.minecraft.class_3489;
import net.minecraft.class_3959;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3965;
import net.minecraft.class_638;
import net.minecraft.class_746;

final class AutoMiner {
   static String homeCmd = "home cat";
   static boolean deathRecover = true;
   static boolean autoRespawn = true;
   static boolean digThrough = true;
   static int scanRadius = 16;
   static final int[] SCAN_LEVELS = new int[]{8, 12, 16, 24};
   static boolean tunnel = false;
   static int tunnelLayers = 3;
   static int tunnelWidth = 3;
   static int tunnelBelow = 0;
   static final int[] TUNNEL_LAYER_LEVELS = new int[]{2, 3, 4, 5, 6, 8};
   static final int[] TUNNEL_WIDTH_LEVELS = new int[]{1, 3, 5};
   static final int[] TUNNEL_BELOW_LEVELS = new int[]{0, 1, 2, 3, 4, 5, 6, 7};
   static boolean tunnelInit = false;
   static boolean tunnelMove = false;
   static class_2350 tunnelDir = class_2350.field_11043;
   static int tunnelAx = 0;
   static int tunnelAz = 0;
   static int tunnelBase = 0;
   static int tunnelFails = 0;
   static int tunnelTurns = 0;
   static int tunnelPause = 0;
   static final double REACH = 4.3;
   static final double EYE_H = 1.62;
   static final int MAX_NODES = 2500;
   static final int MAX_RANGE = 48;
   static final int FALL_MAX = 3;
   static final double DIG_COST = 5.0;
   static final int MINE_TIMEOUT = 160;
   static final int TRAVEL_TIMEOUT = 500;
   static final int MAX_DEPTH = 6;
   static final int COLLECT_R = 12;
   static final int RECOVER_TIMEOUT = 9000;
   static final int RECOVER_NODES = 6000;
   static final int HOME_STILL = 200;
   static final double PEARL_MIN_DIST = 60.0;
   static final double PEARL_STOP_DIST = 12.0;
   static final double PEARL_RANGE = 45.0;
   static final float PEARL_MIN_HP = 12.0F;
   static final int PEARL_MAX_THROWS = 4;
   static final Set<class_2248> DIGGABLE = Set.of(class_2246.field_10102, class_2246.field_10534);
   static final int P_IDLE = 0;
   static final int P_MOVE = 1;
   static final int P_MINE = 2;
   static final int P_ITEM = 3;
   static final int P_EXPLORE = 4;
   static final int RUN = 0;
   static final int DONE = 1;
   static final int FAIL = 2;
   static boolean active = false;
   static int ph = 0;
   static int phTicks = 0;
   static int stuck = 0;
   static int scanCool = 0;
   static int noTarget = 0;
   static int exploreCount = 0;
   static int ignoreAge = 0;
   static int baseY = -1000000;
   static class_2338 target = null;
   static boolean descendPhase = true;
   static boolean descendTarget = false;
   static int descendWaitTicks = 0;
   static int descendDepth = 2;
   static boolean nukerHold = true;
   static int descendStartY = Integer.MIN_VALUE;
   static final int NUKER_HOLD_R = 4;
   static final int NUKER_HOLD_MAX = 60;
   static int nukerHoldTicks = 0;
   static int nukerHoldLast = -1;
   static int nukerHoldCool = 0;
   static boolean nukerHoldHad = false;
   static long nukerHoldAt = -1000L;
   static class_1542 itemTarget = null;
   static List<class_2338> path = null;
   static int pi = 0;
   static class_243 lastPos = null;
   static boolean baritoneOwnsPath = false;
   static double exploreYaw = 0.0;
   static long failKey = Long.MIN_VALUE;
   static int failCount = 0;
   static final Set<Long> ignoreBlocks = new HashSet<>();
   static final Set<Integer> ignoreItems = new HashSet<>();
   static final int R_NONE = 0;
   static final int R_WAIT = 1;
   static final int R_HOME = 2;
   static final int R_WALK = 3;
   static final int R_COLLECT = 4;
   static final int R_ORG = 5;
   static final int R_PEARL = 6;
   static final int R_CROSS = 7;
   static int rec = 0;
   static int recTimer = 0;
   static int recTicks = 0;
   static int recStep = 0;
   static int homeTries = 0;
   static int walkNoProg = 0;
   static int walkFails = 0;
   static int blindTicks = 0;
   static int collectIdle = 0;
   static int collectTicks = 0;
   static int itemWait = 0;
   static double walkBest = Double.MAX_VALUE;
   static boolean deathRecorded = false;
   static boolean shovelWarned = false;
   static class_2338 deathPos = null;
   static Object deathDim = null;
   static int deadTicks = 0;
   static class_243 homeFrom = null;
   static class_243 itemPlanPos = null;
   static String lastDeathText = null;
   static float pearlYaw = 0.0F;
   static float pearlPitch = 0.0F;
   static int kitStep = 2;
   static int kitDropped = 0;
   static float kitXRot = Float.NaN;
   static boolean deathMarker = false;
   static boolean gotShovel = false;
   static boolean teleported = false;
   static boolean canDig = false;
   static boolean pearlDone = false;
   static int pearlBuyFails = 0;
   static int pearlThrows = 0;
   static int pearlStep = 0;
   static int pearlTimer = 0;
   static int pearlHpWait = 0;
   static int arrowCnt = 0;
   static int hpEatCool = 0;
   static int hpEatTries = 0;
   static final int CROSS_MAX_THROWS = 4;
   static final double CROSS_MAX_RANGE = 30.0;
   static int crossThrows = 0;
   static int crossStep = 0;
   static int crossCool = 0;
   static int crossWait = 0;
   static class_243 crossFrom = null;
   static final class_1792[] snap = new class_1792[9];
   static final boolean[] snapShovel = new boolean[9];
   static int snapTick = 0;
   static boolean shaft = false;
   static final int SHAFT_R = 1;
   static final int SHAFT_MAX_DEPTH = 40;
   static boolean shaftInit = false;
   static int shaftX;
   static int shaftZ;
   static int shaftTop;
   static boolean shaftBlocked = false;
   static final int NEAR_RADIUS = 5;
   static int retreatTicks = 0;
   static int retreatCool = 0;
   static int digAcc = 0;
   static List<class_2338> pgPath = null;
   static class_243 pgPos = class_243.field_1353;
   static int pgTicks = 0;
   static int pgFails = 0;
   static int pgHit = 0;
   static boolean orgDone = false;
   static String orgWhy = null;
   static int fixCool = 0;
   static final String[] ARROWS = new String[]{"↑", "↗", "→", "↘", "↓", "↙", "←", "↖"};
   static final double PEARL_SPEED = 1.5;
   static final double PEARL_G = 0.03;
   static final double PEARL_DRAG = 0.99;

   private AutoMiner() {
   }

   static boolean holdingForNuker(class_638 lv) {
      return lv.method_75260() - nukerHoldAt <= 3L;
   }

   static void start(class_746 p) {
      active = true;
      int y = p.method_24515().method_10264();
      if (y > baseY) {
         baseY = y;
      }

      if (rec == 0) {
         path = null;
         target = null;
         itemTarget = null;
         ph = 0;
         phTicks = 0;
         stuck = 0;
      }
   }

   static void stop(class_310 mc) {
      active = false;
      cancelBaritoneNavigation();
      path = null;
      target = null;
      itemTarget = null;
      ph = 0;
      phTicks = 0;
      release(mc);
   }

   static void reset(class_310 mc) {
      orgDone = false;
      tunnelInit = false;
      tunnelMove = false;
      tunnelFails = 0;
      tunnelTurns = 0;
      tunnelPause = 0;
      stop(mc);
      rec = 0;
      deathRecorded = false;
      baseY = -1000000;
      descendPhase = true;
      descendTarget = false;
      descendWaitTicks = 0;
      descendStartY = Integer.MIN_VALUE;
      nukerHoldTicks = 0;
      nukerHoldLast = -1;
      nukerHoldCool = 0;
      nukerHoldHad = false;
      noTarget = 0;
      exploreCount = 0;
      ignoreBlocks.clear();
      ignoreItems.clear();
   }

   static boolean recovering() {
      return rec != 0;
   }

   static void release(class_310 mc) {
      mc.field_1690.field_1894.method_23481(false);
      mc.field_1690.field_1903.method_23481(false);
      mc.field_1690.field_1867.method_23481(false);
      mc.field_1690.field_1886.method_23481(false);
   }

   static void onDead(class_310 mc, class_746 p) {
      release(mc);
      if (!deathRecorded || gotShovel) {
         deathRecorded = true;
         gotShovel = false;
         deadTicks = 0;
         deathPos = p.method_24515();
         deathDim = mc.field_1687 != null ? mc.field_1687.method_27983() : null;
         lastDeathText = deathPos.method_10263() + " " + deathPos.method_10264() + " " + deathPos.method_10260();
         deathMarker = true;
         AutoSandOrders.statDeaths++;
         AutoSandOrders.save();
         AutoSandOrders.msg(p, "Đã chết tại " + lastDeathText + " (đã ghi nhớ toạ độ).");
      }

      if (autoRespawn && ++deadTicks % 20 == 10) {
         p.method_7331();
      }
   }

   static void freshStart() {
      cancelBaritoneNavigation();
      ignoreBlocks.clear();
      ignoreItems.clear();
      ignoreAge = 0;
      tunnelInit = false;
      tunnelMove = false;
      tunnelFails = 0;
      tunnelTurns = 0;
      tunnelPause = 0;
      shaftInit = false;
      shaftBlocked = false;
      scanCool = 0;
      noTarget = 0;
      exploreCount = 0;
      path = null;
      target = null;
      itemTarget = null;
      ph = 0;
      phTicks = 0;
      stuck = 0;
   }

   static void onRespawn(class_310 mc, class_746 p) {
      freshStart();
      path = null;
      target = null;
      itemTarget = null;
      ph = 0;
      release(mc);
      baseY = -1000000;
      tunnelInit = false;
      tunnelMove = false;
      if (deathRecorded && deathPos != null) {
         rec = 1;
         recTimer = 40;
         recTicks = 0;
         recStep = 0;
         homeTries = 0;
         walkNoProg = 0;
         walkFails = 0;
         blindTicks = 0;
         walkBest = Double.MAX_VALUE;
         collectIdle = 0;
         shovelWarned = false;
         pearlDone = false;
         pearlBuyFails = 0;
         crossThrows = 0;
         crossStep = 0;
         crossCool = 0;
         teleported = false;
         kitStep = 0;
         kitDropped = 0;
         orgDone = false;
         ignoreItems.clear();
         AutoSandOrders.msg(p, "Đã hồi sinh. Chuẩn bị /" + homeCmd + ", đứng yên 10 giây rồi mới đi tiếp.");
      } else {
         deathRecorded = false;
      }
   }

   static String deathText() {
      return lastDeathText == null ? "Chưa chết lần nào" : "Chết ở " + lastDeathText;
   }

   static String recoverText() {
      return switch (rec) {
         case 1 -> "Vừa hồi sinh, chuẩn bị về home";
         case 2 -> "Chờ /" + homeCmd + " dịch chuyển";
         case 3 -> "Đang đi về chỗ chết";
         case 4 -> "Đang nhặt đồ rơi lúc chết";
         case 5 -> "Đang xếp xẻng / đồ lên thanh công cụ";
         case 6 -> "Đang ném ngọc Ender tới chỗ chết";
         case 7 -> "Đang ném ngọc Ender qua nước";
         default -> "Đang đào cát";
      };
   }

   static void tick(class_310 mc, class_746 p) {
      class_638 lv = mc.field_1687;
      if (lv != null) {
         canDig = digThrough && hotbarShovel(p) >= 0;
         if (rec != 0) {
            if (AutoSandOrders.useNuker) {
               AutoSandOrders.setNuker(p, false);
            }

            tickRecovery(mc, p, lv);
         } else if (active) {
            if (tunnelPause > 0) {
               tunnelPause--;
            }

            fixShovel(mc, p);
            if (!waterRetreat(mc, p, lv)) {
               phTicks++;
               if (scanCool > 0) {
                  scanCool--;
               }

               switch (ph) {
                  case 0:
                     chooseAction(mc, p, lv);
                     break;
                  case 1:
                  case 3:
                  case 4:
                     tickTravel(mc, p, lv);
                     break;
                  case 2:
                     tickMine(mc, p, lv);
                     break;
                  default:
                     ph = 0;
               }
            }
         }
      }
   }

   static void snapshot(class_746 p) {
      if (!deathRecorded && rec == 0) {
         if (++snapTick >= 40) {
            snapTick = 0;
            boolean has = false;

            for (int i = 0; i < 9; i++) {
               if (p.method_31548().method_5438(i).method_31573(class_3489.field_42615)) {
                  has = true;
               }
            }

            if (has) {
               for (int ix = 0; ix < 9; ix++) {
                  class_1799 st = p.method_31548().method_5438(ix);
                  snap[ix] = st.method_7960() ? null : st.method_7909();
                  snapShovel[ix] = st.method_31573(class_3489.field_42615);
               }
            }
         }
      }
   }

   static void chooseAction(class_310 mc, class_746 p, class_638 lv) {
      release(mc);
      if (scanCool <= 0) {
         if (ignoreBlocks.size() > 200 || ++ignoreAge > 1200) {
            ignoreBlocks.clear();
            ignoreItems.clear();
            ignoreAge = 0;
         }

         if (descendPhase && planDescendSand(p, lv)) {
            noTarget = 0;
            exploreCount = 0;
         } else {
            if (AutoSandOrders.pickupRadius > 0 && !AutoSandOrders.isFull(p)) {
               class_1542 it = findDrop(lv, p, p.method_73189(), AutoSandOrders.pickupRadius, true);
               if (it != null) {
                  class_243 ip = it.method_73189();
                  List<class_2338> r = findPath(
                     lv,
                     p.method_24515(),
                     ip,
                     q -> Math.hypot(q.method_10263() + 0.5 - ip.field_1352, q.method_10260() + 0.5 - ip.field_1350) < 0.9 && Math.abs(q.method_10264() - ip.field_1351) < 2.0,
                     1200,
                     false
                  );
                  if (r != null && !r.isEmpty()) {
                     itemTarget = it;
                     path = r;
                     pi = 0;
                     stuck = 0;
                     ph = 3;
                     phTicks = 0;
                     return;
                  }

                  ignoreItems.add(it.method_5628());
               }
            }

            if (nukerHold(mc, p, lv)) {
               noTarget = 0;
               exploreCount = 0;
            } else if (planToSand(p, lv)) {
               noTarget = 0;
               exploreCount = 0;
            } else {
               baseY = p.method_24515().method_10264();
               if (++exploreCount > 40 || !planExplore(lv, p)) {
                  scanCool = 40;
                  if (++noTarget >= 10 || exploreCount > 40) {
                     AutoSandOrders.msg(p, "Không tìm thấy cát quanh đây và không thăm dò thêm được. Tắt AutoSand.");
                     AutoSandOrders.setEnabled(mc, false);
                  }
               }
            }
         }
      }
   }

   static class_2338 tunnelCell(int s, int w, int y) {
      int fx = tunnelDir.method_10148();
      int fz = tunnelDir.method_10165();
      return new class_2338(tunnelAx + fx * s - fz * w, y, tunnelAz + fz * s + fx * w);
   }

   static int tunnelProgress(class_2338 b) {
      return (b.method_10263() - tunnelAx) * tunnelDir.method_10148() + (b.method_10260() - tunnelAz) * tunnelDir.method_10165();
   }

   static int tunnelLateral(class_2338 b) {
      return -(b.method_10263() - tunnelAx) * tunnelDir.method_10165() + (b.method_10260() - tunnelAz) * tunnelDir.method_10148();
   }

   static void tunnelStart(class_746 p, class_2350 d, boolean keepBase) {
      class_2338 b = p.method_24515();
      tunnelDir = d;
      tunnelAx = b.method_10263();
      tunnelAz = b.method_10260();
      if (!keepBase) {
         tunnelBase = b.method_10264();
      }

      tunnelInit = true;
      tunnelFails = 0;
   }

   static boolean tunnelTurn(class_746 p, String why) {
      tunnelTurns++;
      if (tunnelTurns > 2) {
         tunnelTurns = 0;
         tunnelPause = 1200;
         tunnelInit = false;
         AutoSandOrders.msg(p, "Đào hầm dừng: " + why + ". Chuyển sang đào thường 1 phút.");
         return false;
      } else {
         tunnelStart(p, tunnelTurns == 1 ? tunnelDir.method_10170() : tunnelDir.method_10153(), true);
         AutoSandOrders.msg(p, "Đào hầm: " + why + " -> rẽ sang hướng khác.");
         return true;
      }
   }

   static boolean planTunnel(class_310 mc, class_746 p, class_638 lv) {
      class_2338 me = p.method_24515();
      if (tunnelInit && (Math.abs(tunnelLateral(me)) > 3 || Math.abs(me.method_10264() - tunnelBase) > 6 + tunnelBelow)) {
         tunnelInit = false;
      }

      if (!tunnelInit) {
         tunnelStart(p, p.method_5735(), false);
      }

      if (tunnelFails >= 3) {
         tunnelFails = 0;
         return tunnelTurn(p, "không đi tiếp được");
      } else {
         int half = tunnelWidth / 2;
         int yMin = tunnelBase - tunnelBelow;
         int yMax = yMin + tunnelLayers - 1;
         int s0 = tunnelProgress(me);
         class_243 eye = p.method_33571();
         List<AutoMiner.Cand> cells = new ArrayList<>();
         boolean sandAhead = false;

         for (int s = s0; s <= s0 + 8; s++) {
            for (int w = -half; w <= half; w++) {
               for (int y = yMax; y >= yMin; y--) {
                  class_2338 c = tunnelCell(s, w, y);
                  if (lv.method_8320(c).method_27852(class_2246.field_10102)) {
                     sandAhead = true;
                     if (s <= s0 + 2 && !ignoreBlocks.contains(c.method_10063()) && !underOrOver(p, c)) {
                        cells.add(new AutoMiner.Cand(c, (s - s0) * 100.0 + (yMax - y) * 10.0 + Math.abs(w)));
                     }
                  }
               }
            }
         }

         cells.sort(Comparator.comparingDouble(c -> c.score));

         for (AutoMiner.Cand c : cells) {
            if (waterWithin(lv, c.pos, 2)) {
               ignoreBlocks.add(c.pos.method_10063());
            } else if (canMineFromEye(lv, p, eye, c.pos)) {
               target = c.pos;
               path = null;
               ph = 2;
               phTicks = 0;
               tunnelFails = 0;
               tunnelTurns = 0;
               tunnelMove = false;
               return true;
            }
         }

         if (!sandAhead) {
            return tunnelTurn(p, "hết cát phía trước");
         } else {
            class_2338 f1 = tunnelCell(s0 + 1, 0, me.method_10264());

            for (class_2338 q : new class_2338[]{f1, f1.method_10084()}) {
               class_2680 st = lv.method_8320(q);
               if (!st.method_26227().method_15769() || hazardState(st)) {
                  return tunnelTurn(p, "có nước / vật nguy hiểm phía trước");
               }

               if (!st.method_26220(lv, q).method_1110() && !st.method_27852(class_2246.field_10102)) {
                  return tunnelTurn(p, "bị chặn bởi khối không phải cát");
               }
            }

            int gx = f1.method_10263();
            int gz = f1.method_10260();
            List<class_2338> r = findPath(
               lv, me, class_243.method_24953(f1), qx -> qx.method_10263() == gx && qx.method_10260() == gz && Math.abs(qx.method_10264() - me.method_10264()) <= 3, 800, false
            );
            if (r != null && !r.isEmpty()) {
               path = r;
               pi = 0;
               stuck = 0;
               tunnelMove = true;
               ph = 4;
               phTicks = 0;
               return true;
            } else {
               tunnelFails++;
               scanCool = 5;
               return true;
            }
         }
      }
   }

   static boolean planShaft(class_746 p, class_638 lv) {
      shaftBlocked = false;
      class_2338 me = p.method_24515();
      if (shaftInit && (Math.abs(p.method_23317() - (shaftX + 0.5)) > 1.2 || Math.abs(p.method_23321() - (shaftZ + 0.5)) > 1.2)) {
         shaftInit = false;
      }

      if (!shaftInit) {
         if (!p.method_24828()) {
            return true;
         }

         shaftX = me.method_10263();
         shaftZ = me.method_10260();
         shaftTop = me.method_10264();
         shaftInit = true;
      }

      if (!p.method_24828()) {
         return true;
      } else if (shaftTop - me.method_10264() >= 40) {
         shaftBlocked = true;
         return false;
      } else {
         class_2338 below = new class_2338(shaftX, me.method_10264() - 1, shaftZ);
         if (lv.method_8320(below).method_27852(class_2246.field_10102) && !ignoreBlocks.contains(below.method_10063()) && !waterWithin(lv, below, 2)) {
            boolean landing = false;

            for (int k = 1; k <= 3 && !landing; k++) {
               if (!lv.method_8320(below.method_10087(k)).method_26215()) {
                  landing = true;
               }
            }

            if (landing) {
               target = below;
               path = null;
               ph = 2;
               phTicks = 0;
               return true;
            }
         }

         class_243 eye = p.method_33571();

         for (int y = me.method_10264() + 1; y >= me.method_10264(); y--) {
            for (int dx = -1; dx <= 1; dx++) {
               for (int dz = -1; dz <= 1; dz++) {
                  class_2338 c = new class_2338(shaftX + dx, y, shaftZ + dz);
                  if (lv.method_8320(c).method_27852(class_2246.field_10102) && !ignoreBlocks.contains(c.method_10063())) {
                     if (waterWithin(lv, c, 2)) {
                        ignoreBlocks.add(c.method_10063());
                     } else if (canMineFromEye(lv, p, eye, c)) {
                        target = c;
                        path = null;
                        ph = 2;
                        phTicks = 0;
                        return true;
                     }
                  }
               }
            }
         }

         shaftBlocked = true;
         return false;
      }
   }

   static int sandInReach(class_638 lv, class_746 p, int r) {
      class_2338 o = class_2338.method_49637(p.method_23317(), p.method_23320(), p.method_23321());
      class_2339 m = new class_2339();
      int n = 0;

      for (int dx = -r; dx <= r; dx++) {
         for (int dy = -r; dy <= r; dy++) {
            for (int dz = -r; dz <= r; dz++) {
               if (dx * dx + dy * dy + dz * dz <= r * r) {
                  m.method_10103(o.method_10263() + dx, o.method_10264() + dy, o.method_10260() + dz);
                  if (lv.method_8320(m).method_27852(class_2246.field_10102)) {
                     n++;
                  }
               }
            }
         }
      }

      return n;
   }

   static boolean nukerHold(class_310 mc, class_746 p, class_638 lv) {
      if (!nukerHold || !AutoSandOrders.useNuker || AutoSandOrders.nukerWater || !Boolean.TRUE.equals(AutoSandOrders.nukerState)) {
         nukerHoldTicks = 0;
         nukerHoldLast = -1;
         return false;
      } else if (nukerHoldCool > 0) {
         nukerHoldCool--;
         return false;
      } else if (p.method_24828() && !p.method_5799() && !p.method_5771()) {
         int n = sandInReach(lv, p, 4);
         if (n == 0) {
            if (nukerHoldHad) {
               nukerHoldHad = false;
               nukerHoldTicks = 0;
               nukerHoldLast = -1;
               if (descendDepth > 0) {
                  descendPhase = true;
                  descendStartY = Integer.MIN_VALUE;
                  descendWaitTicks = 0;
                  return true;
               }
            }

            return false;
         } else {
            nukerHoldHad = true;
            if (nukerHoldLast >= 0 && n >= nukerHoldLast) {
               if (++nukerHoldTicks > 60) {
                  nukerHoldTicks = 0;
                  nukerHoldLast = -1;
                  nukerHoldCool = 200;
                  nukerHoldHad = false;
                  return false;
               }
            } else {
               nukerHoldLast = n;
               nukerHoldTicks = 0;
            }

            nukerHoldAt = lv.method_75260();
            release(mc);
            return true;
         }
      } else {
         return false;
      }
   }

   static boolean planDescendSand(class_746 p, class_638 lv) {
      class_2338 feet = p.method_24515();
      class_2338 below = feet.method_10074();
      if (!p.method_5799() && !p.method_5771() && !AutoSandOrders.liquidAt(lv, below) && !AutoSandOrders.lavaAt(lv, below)) {
         if (descendStartY == Integer.MIN_VALUE) {
            descendStartY = feet.method_10264();
         }

         if (descendDepth > 0 && p.method_24828() && descendStartY - feet.method_10264() >= descendDepth) {
            descendPhase = false;
            descendTarget = false;
            descendWaitTicks = 0;
            return false;
         } else if (lv.method_8320(below).method_27852(class_2246.field_10102)
            && !ignoreBlocks.contains(below.method_10063())
            && !waterWithin(lv, below, 1)
            && canMineFromEye(lv, p, p.method_33571(), below)) {
            descendWaitTicks = 0;
            target = below;
            descendTarget = true;
            path = null;
            ph = 2;
            phTicks = 0;
            return true;
         } else if (AutoSandOrders.passable(lv, below) && descendWaitTicks < 40) {
            descendWaitTicks++;
            descendTarget = false;
            target = null;
            path = null;
            ph = 0;
            phTicks = 0;
            release(class_310.method_1551());
            return true;
         } else {
            descendPhase = false;
            descendTarget = false;
            descendWaitTicks = 0;
            return false;
         }
      } else {
         descendPhase = false;
         descendTarget = false;
         descendWaitTicks = 0;
         return false;
      }
   }

   static class_2338 findBestNearSand(class_638 lv, class_746 p) {
      class_2338 origin = p.method_24515();
      List<class_2338> list = new ArrayList<>();

      for (int dx = -5; dx <= 5; dx++) {
         for (int dz = -5; dz <= 5; dz++) {
            for (int dy = -3; dy <= 4; dy++) {
               class_2338 bp = origin.method_10069(dx, dy, dz);
               if (lv.method_8320(bp).method_27852(class_2246.field_10102) && !ignoreBlocks.contains(bp.method_10063()) && !underOrOver(p, bp) && !waterWithin(lv, bp, 2)) {
                  boolean exposed = false;

                  for (class_2350 d : class_2350.values()) {
                     class_2338 nb = bp.method_10093(d);
                     if (lv.method_8320(nb).method_26220(lv, nb).method_1110()) {
                        exposed = true;
                        break;
                     }
                  }

                  if (exposed) {
                     list.add(bp);
                  }
               }
            }
         }
      }

      list.sort(Comparator.comparingDouble(cx -> scoreNear(p, cx)));
      class_243 eye = p.method_33571();

      for (class_2338 c : list) {
         if (canMineFromEye(lv, p, eye, c)) {
            return c;
         }
      }

      return list.isEmpty() ? null : list.get(0);
   }

   static double scoreNear(class_746 p, class_2338 b) {
      double dx = b.method_10263() + 0.5 - p.method_23317();
      double dz = b.method_10260() + 0.5 - p.method_23321();
      double dist = Math.hypot(dx, dz);
      int dy = b.method_10264() - p.method_24515().method_10264();
      if (dy < 0 && dist < 1.6) {
         return dist - 15.0;
      } else {
         return Math.abs(dy) <= 1 && dist < 2.8 ? dist - 6.0 : dist + Math.abs(dy) * 0.5;
      }
   }

   static boolean planToSand(class_746 p, class_638 lv) {
      class_2338 c = findBestNearSand(lv, p);
      if (c == null) {
         return false;
      } else {
         target = c;
         descendTarget = false;
         path = null;
         pi = 0;
         phTicks = 0;
         if (canMineFromEye(lv, p, p.method_33571(), c)) {
            ph = 2;
            return true;
         } else if (startBaritoneToSand(c)) {
            ph = 1;
            return true;
         } else {
            List<class_2338> r = pathToSand(lv, p, c);
            if (r != null && !r.isEmpty()) {
               path = r;
               pi = 0;
               stuck = 0;
               ph = 1;
               return true;
            } else {
               ignoreBlocks.add(c.method_10063());
               target = null;
               ph = 0;
               scanCool = 2;
               return false;
            }
         }
      }
   }

   static List<class_2338> pathToSand(class_638 lv, class_746 p, class_2338 sand) {
      return findPath(lv, p.method_24515(), class_243.method_24953(sand), q -> canMineFromStand(lv, p, q, sand), 2500, false);
   }

   static boolean canMineFromStand(class_638 lv, class_746 p, class_2338 stand, class_2338 sand) {
      if (Math.abs(stand.method_10263() - sand.method_10263()) + Math.abs(stand.method_10264() - sand.method_10264()) + Math.abs(stand.method_10260() - sand.method_10260()) > 1) {
         return false;
      } else {
         class_243 eye = new class_243(stand.method_10263() + 0.5, stand.method_10264() + 1.62, stand.method_10260() + 0.5);
         class_243 center = class_243.method_24953(sand);
         if (eye.method_1025(center) > 18.49) {
            return false;
         } else {
            class_3965 hit = lv.method_17742(new class_3959(eye, center, net.minecraft.class_3959.class_3960.field_17558, class_242.field_1348, p));
            return hit.method_17783() == class_240.field_1332 && hit.method_17777().equals(sand);
         }
      }
   }

   static boolean startBaritoneToSand(class_2338 sand) {
      baritoneOwnsPath = BaritoneBridge.goTo(sand);
      return baritoneOwnsPath;
   }

   static void restoreBaritoneSettings() {
      BaritoneBridge.restore();
   }

   static void cancelBaritoneNavigation() {
      if (baritoneOwnsPath) {
         BaritoneBridge.cancel();
      }

      baritoneOwnsPath = false;
   }

   static int tickBaritoneTravel(class_310 mc, class_746 p, class_638 lv) {
      if (target == null || !lv.method_8320(target).method_27852(class_2246.field_10102) || waterWithin(lv, target, 2)) {
         cancelBaritoneNavigation();
         target = null;
         ph = 0;
         phTicks = 0;
         scanCool = 2;
         return 2;
      } else if (BaritoneBridge.isBusy()) {
         return 0;
      } else if (canMineFromEye(lv, p, p.method_33571(), target)) {
         baritoneOwnsPath = false;
         restoreBaritoneSettings();
         return 1;
      } else if (phTicks < 12) {
         return 0;
      } else {
         baritoneOwnsPath = false;
         restoreBaritoneSettings();
         List<class_2338> r = pathToSand(lv, p, target);
         if (r != null && !r.isEmpty()) {
            path = r;
            pi = 0;
            stuck = 0;
            return 0;
         } else {
            return 2;
         }
      }
   }

   static boolean planExplore(class_638 lv, class_746 p) {
      class_2338 start = p.method_24515();
      double[] offs = new double[]{0.0, 90.0, -90.0, 180.0, 45.0, -45.0};

      for (double off : offs) {
         double ang = Math.toRadians(exploreYaw + off);
         double tx = p.method_23317() - Math.sin(ang) * 26.0;
         double tz = p.method_23321() + Math.cos(ang) * 26.0;
         class_243 t = new class_243(tx, p.method_23318(), tz);
         List<class_2338> r = findPath(lv, start, t, q -> Math.hypot(q.method_10263() + 0.5 - tx, q.method_10260() + 0.5 - tz) < 3.0, 2500, true);
         if (r != null && r.size() >= 4) {
            exploreYaw += off;
            path = r;
            pi = 0;
            stuck = 0;
            ph = 4;
            phTicks = 0;
            return true;
         }
      }

      exploreYaw = Math.random() * 360.0;
      return false;
   }

   static boolean waterWithin(class_638 lv, class_2338 b, int r) {
      if (lv == null) {
         return false;
      } else {
         class_2339 m = new class_2339();

         for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
               for (int dy = -r; dy <= r + 1; dy++) {
                  m.method_10103(b.method_10263() + dx, b.method_10264() + dy, b.method_10260() + dz);
                  if (!lv.method_8320(m).method_26227().method_15769()) {
                     return true;
                  }
               }
            }
         }

         return false;
      }
   }

   static boolean fluidAdj(class_638 lv, class_2338 b) {
      for (class_2350 d : AutoSandOrders.HORIZ) {
         class_2338 n = b.method_10093(d);
         if (!lv.method_8320(n).method_26227().method_15769() || !lv.method_8320(n.method_10084()).method_26227().method_15769()) {
            return true;
         }
      }

      return false;
   }

   static boolean waterRetreat(class_310 mc, class_746 p, class_638 lv) {
      if (retreatCool > 0) {
         retreatCool--;
      }

      if (retreatTicks > 0) {
         retreatTicks--;
         mc.field_1690.field_1894.method_23481(true);
         mc.field_1690.field_1867.method_23481(true);
         mc.field_1690.field_1903.method_23481(false);
         mc.field_1690.field_1886.method_23481(false);
         if (retreatTicks == 0) {
            release(mc);
            retreatCool = 60;
            scanCool = 0;
         }

         return true;
      } else if (retreatCool <= 0 && !p.method_5799() && !p.method_5771()) {
         class_2338 o = p.method_24515();
         double sx = 0.0;
         double sz = 0.0;
         int n = 0;

         for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
               for (int dy = -1; dy <= 2; dy++) {
                  if (!lv.method_8320(o.method_10069(dx, dy, dz)).method_26227().method_15769()) {
                     sx += dx;
                     sz += dz;
                     n++;
                  }
               }
            }
         }

         if (n == 0) {
            return false;
         } else {
            double ax = -sx / n;
            double az = -sz / n;
            double len = Math.hypot(ax, az);
            if (len < 0.3) {
               return false;
            } else {
               ax /= len;
               az /= len;
               if (AutoSandOrders.hazardDir(lv, p.method_23317(), p.method_23318(), p.method_23321(), ax, az)) {
                  return false;
               } else {
                  cancelBaritoneNavigation();
                  path = null;
                  target = null;
                  itemTarget = null;
                  ph = 0;
                  phTicks = 0;
                  release(mc);
                  p.method_36456((float)Math.toDegrees(Math.atan2(-ax, az)));
                  p.method_36457(0.0F);
                  retreatTicks = 10;
                  return true;
               }
            }
         }
      } else {
         return false;
      }
   }

   static List<class_2338> scanSand(class_638 lv, class_746 p) {
      class_2338 o = p.method_24515();
      int r = scanRadius;
      List<AutoMiner.Cand> list = new ArrayList<>();
      class_2339 m = new class_2339();

      for (int dy = -6; dy <= 5; dy++) {
         int y = o.method_10264() + dy;
         if (y >= baseY - 6) {
            for (int dx = -r; dx <= r; dx++) {
               for (int dz = -r; dz <= r; dz++) {
                  m.method_10103(o.method_10263() + dx, y, o.method_10260() + dz);
                  if (lv.method_8320(m).method_27852(class_2246.field_10102) && !ignoreBlocks.contains(m.method_10063()) && !underOrOver(p, m)) {
                     boolean open = false;
                     boolean bad = false;

                     for (class_2350 d : class_2350.values()) {
                        class_2338 nb = m.method_10093(d);
                        class_2680 ns = lv.method_8320(nb);
                        if (!ns.method_26227().method_15769()) {
                           bad = true;
                           break;
                        }

                        if (ns.method_26220(lv, nb).method_1110()) {
                           open = true;
                        }
                     }

                     if (!bad && open) {
                        list.add(new AutoMiner.Cand(m.method_10062(), dx * dx + dz * dz + 3.0 * dy * dy));
                     }
                  }
               }
            }
         }
      }

      list.sort(Comparator.comparingDouble(cx -> cx.score));
      List<class_2338> out = new ArrayList<>();

      for (int i = 0; i < list.size() && out.size() < 12; i++) {
         class_2338 c = list.get(i).pos;
         if (!waterWithin(lv, c, 2)) {
            out.add(c);
         }
      }

      return out;
   }

   static boolean underOrOver(class_746 p, class_2338 b) {
      if (b.method_10263() + 1 <= p.method_23317() - 0.35 || b.method_10263() >= p.method_23317() + 0.35) {
         return false;
      } else if (!(b.method_10260() + 1 <= p.method_23321() - 0.35) && !(b.method_10260() >= p.method_23321() + 0.35)) {
         int fy = p.method_24515().method_10264();
         return b.method_10264() == fy - 1 || b.method_10264() >= fy + 2;
      } else {
         return false;
      }
   }

   static boolean colBlocked(class_2338 stand, class_2338 t) {
      return t.method_10263() == stand.method_10263() && t.method_10260() == stand.method_10260() && (t.method_10264() == stand.method_10264() - 1 || t.method_10264() >= stand.method_10264() + 2);
   }

   static boolean canMineFromEye(class_638 lv, class_746 p, class_243 eye, class_2338 t) {
      class_243 c = class_243.method_24953(t);
      if (eye.method_1025(c) > 18.49) {
         return false;
      } else {
         class_3965 r = lv.method_17742(new class_3959(eye, c, net.minecraft.class_3959.class_3960.field_17558, class_242.field_1348, p));
         return r.method_17783() == class_240.field_1332 && r.method_17777().equals(t);
      }
   }

   static class_1542 findDrop(class_638 lv, class_746 p, class_243 c, double r, boolean sandOnly) {
      class_238 box = new class_238(c.field_1352 - r, c.field_1351 - 5.0, c.field_1350 - r, c.field_1352 + r, c.field_1351 + 5.0, c.field_1350 + r);
      List<class_1542> list = lv.method_8390(
         class_1542.class, box, ex -> !ex.method_31481() && (!sandOnly || ex.method_6983().method_31574(class_1802.field_8858)) && !ignoreItems.contains(ex.method_5628())
      );
      class_1542 best = null;
      double bd = Double.MAX_VALUE;

      for (class_1542 e : list) {
         double dx = e.method_23317() - p.method_23317();
         double dz = e.method_23321() - p.method_23321();
         double d = dx * dx + dz * dz;
         if ((!sandOnly || !(d < 1.44) || !(Math.abs(e.method_23318() - p.method_23318()) < 1.5)) && d < bd) {
            bd = d;
            best = e;
         }
      }

      return best;
   }

   static void tickTravel(class_310 mc, class_746 p, class_638 lv) {
      if (phTicks > 500) {
         failTravel(mc);
      } else {
         if (ph == 1 && baritoneOwnsPath) {
            int br = tickBaritoneTravel(mc, p, lv);
            if (br != 0) {
               if (br == 2) {
                  failTravel(mc);
                  return;
               }

               release(mc);
               path = null;
               ph = 2;
               phTicks = 0;
               return;
            }

            if (baritoneOwnsPath) {
               return;
            }
         }

         if (ph == 3) {
            if (itemTarget == null || itemTarget.method_31481() || AutoSandOrders.isFull(p)) {
               endTravel(mc);
               return;
            }
         } else if (ph == 1 && (target == null || !lv.method_8320(target).method_27852(class_2246.field_10102))) {
            endTravel(mc);
            return;
         }

         int r = followPath(mc, p, lv);
         if (r != 0) {
            release(mc);
            if (r == 2) {
               failTravel(mc);
            } else if (ph == 1) {
               path = null;
               ph = 2;
               phTicks = 0;
            } else {
               if (ph == 3 && itemTarget != null && !itemTarget.method_31481()) {
                  ignoreItems.add(itemTarget.method_5628());
               }

               endTravel(mc);
            }
         }
      }
   }

   static void failTravel(class_310 mc) {
      cancelBaritoneNavigation();
      if (tunnelMove) {
         tunnelFails++;
      }

      if (ph == 1 && target != null) {
         ignoreBlocks.add(target.method_10063());
      }

      if (ph == 3 && itemTarget != null) {
         ignoreItems.add(itemTarget.method_5628());
      }

      endTravel(mc);
   }

   static void endTravel(class_310 mc) {
      cancelBaritoneNavigation();
      tunnelMove = false;
      release(mc);
      path = null;
      itemTarget = null;
      target = null;
      ph = 0;
      phTicks = 0;
      scanCool = 2;
   }

   static void tickMine(class_310 mc, class_746 p, class_638 lv) {
      release(mc);
      class_2338 t = target;
      if (t != null && lv.method_8320(t).method_27852(class_2246.field_10102)) {
         boolean shaftCell = shaft && t.method_10263() == shaftX && t.method_10260() == shaftZ;
         if (phTicks <= 160 && (shaftCell || descendTarget || !underOrOver(p, t))) {
            if (!canMineFromEye(lv, p, p.method_33571(), t)) {
               if (t.method_10063() == failKey) {
                  failCount++;
               } else {
                  failKey = t.method_10063();
                  failCount = 1;
               }

               if (failCount >= 3) {
                  ignoreBlocks.add(t.method_10063());
                  failCount = 0;
               }

               target = null;
               descendTarget = false;
               ph = 0;
               phTicks = 0;
               scanCool = 2;
            } else {
               digBlock(mc, p, t);
            }
         } else {
            ignoreBlocks.add(t.method_10063());
            target = null;
            ph = 0;
            phTicks = 0;
            scanCool = 2;
         }
      } else {
         target = null;
         descendTarget = false;
         ph = 0;
         phTicks = 0;
         scanCool = 0;
      }
   }

   static void digBlock(class_310 mc, class_746 p, class_2338 b) {
      class_243 c = class_243.method_24953(b);
      aimAt(p, c);
      ensureShovel(p);
      class_243 e = p.method_33571();
      class_2350 face = class_2350.method_10142(e.field_1352 - c.field_1352, e.field_1351 - c.field_1351, e.field_1350 - c.field_1350);
      digAcc = Math.min(10000, digAcc + AutoSandOrders.mineSpeed);
      int calls = 0;

      while (digAcc >= 100 && calls < 5) {
         digAcc -= 100;
         mc.field_1761.method_2902(b, face);
         p.method_6104(class_1268.field_5808);
         calls++;
         if (mc.field_1687.method_8320(b).method_26215()) {
            digAcc = 0;
            break;
         }
      }
   }

   static void aimAt(class_746 p, class_243 t) {
      class_243 e = p.method_33571();
      double dx = t.field_1352 - e.field_1352;
      double dy = t.field_1351 - e.field_1351;
      double dz = t.field_1350 - e.field_1350;
      p.method_36456((float)Math.toDegrees(Math.atan2(-dx, dz)));
      p.method_36457((float)(-Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz)))));
   }

   static void ensureShovel(class_746 p) {
      if (!p.method_31548().method_5438(AutoSandOrders.getSelected(p)).method_31573(class_3489.field_42615)) {
         int hs = hotbarShovel(p);
         if (hs >= 0) {
            AutoSandOrders.setSelected(p, hs);
         }
      }
   }

   static int followPath(class_310 mc, class_746 p, class_638 lv) {
      if (path == null) {
         return 1;
      } else {
         class_243 pos;
         for (pos = p.method_73189(); pi < path.size(); stuck = 0) {
            class_2338 q = path.get(pi);
            double qx = q.method_10263() + 0.5 - pos.field_1352;
            double qz = q.method_10260() + 0.5 - pos.field_1350;
            double qy = pos.field_1351 - q.method_10264();
            if (!(Math.hypot(qx, qz) < 0.3) || !(qy < 1.2) || !(qy > -1.2)) {
               break;
            }

            pi++;
         }

         if (pi >= path.size()) {
            release(mc);
            return 1;
         } else {
            class_2338 n = path.get(pi);
            double dx = n.method_10263() + 0.5 - pos.field_1352;
            double dz = n.method_10260() + 0.5 - pos.field_1350;
            double dist = Math.hypot(dx, dz);
            if (!(dist > 6.0) && !(Math.abs(pos.field_1351 - n.method_10264()) > 4.0)) {
               class_2338 from = p.method_24515();
               class_2338 blocker = null;
               if (!AutoSandOrders.passable(lv, n)) {
                  blocker = n;
               } else if (!AutoSandOrders.passable(lv, n.method_10084())) {
                  blocker = n.method_10084();
               } else if (n.method_10264() > from.method_10264() && !AutoSandOrders.passable(lv, from.method_10086(2))) {
                  blocker = from.method_10086(2);
               }

               if (blocker != null) {
                  class_2248 bk = lv.method_8320(blocker).method_26204();
                  if (!canDig || !DIGGABLE.contains(bk)) {
                     return 2;
                  } else if (p.method_33571().method_1025(class_243.method_24953(blocker)) > 18.49) {
                     return 2;
                  } else {
                     release(mc);
                     digBlock(mc, p, blocker);
                     stuck = 0;
                     return 0;
                  }
               } else {
                  if (dist > 0.12) {
                     p.method_36456((float)Math.toDegrees(Math.atan2(-dx, dz)));
                  }

                  p.method_36457(0.0F);
                  boolean dropAhead = n.method_10264() < pos.field_1351 - 1.0;
                  mc.field_1690.field_1894.method_23481(!dropAhead || !(dist < 0.5));
                  boolean jump = n.method_10264() > pos.field_1351 + 0.3 && dist < 1.7 || p.field_5976 && p.method_24828();
                  mc.field_1690.field_1903.method_23481(jump);
                  mc.field_1690.field_1867.method_23481(dist > 0.1 && !dropAhead);
                  if (lastPos != null && pos.method_1025(lastPos) < 0.0016) {
                     if (++stuck > 40) {
                        return 2;
                     }
                  } else {
                     stuck = 0;
                  }

                  lastPos = pos;
                  if (pgPath != path) {
                     pgPath = path;
                     pgPos = pos;
                     pgTicks = 0;
                     pgFails = 0;
                     pgHit = 0;
                  }

                  if (p.field_5976) {
                     pgHit++;
                  }

                  if (++pgTicks >= 20) {
                     double mv2 = pos.method_1025(pgPos);
                     if (mv2 < 0.0625) {
                        pgFails++;
                     } else {
                        pgFails = 0;
                     }

                     boolean rammed = pgHit >= 15 && mv2 < 0.36;
                     pgPos = pos;
                     pgTicks = 0;
                     pgHit = 0;
                     if (pgFails >= 2 || rammed) {
                        pgFails = 0;
                        return 2;
                     }
                  }

                  return 0;
               }
            } else {
               return 2;
            }
         }
      }
   }

   static boolean hazardState(class_2680 s) {
      return s.method_27852(class_2246.field_10029)
         || s.method_27852(class_2246.field_10036)
         || s.method_27852(class_2246.field_22089)
         || s.method_27852(class_2246.field_10092)
         || s.method_27852(class_2246.field_16999)
         || s.method_27852(class_2246.field_10606)
         || s.method_27852(class_2246.field_27879)
         || s.method_27852(class_2246.field_10343)
         || s.method_27852(class_2246.field_17350)
         || s.method_27852(class_2246.field_23860)
         || s.method_26227().method_15767(class_3486.field_15518);
   }

   static double cellCost(class_638 lv, class_2338 c) {
      class_2680 s = lv.method_8320(c);
      if (hazardState(s) || !s.method_26227().method_15769()) {
         return -1.0;
      } else if (s.method_26220(lv, c).method_1110()) {
         return 0.0;
      } else {
         return canDig && DIGGABLE.contains(s.method_26204()) ? 5.0 : -1.0;
      }
   }

   static boolean solidGround(class_638 lv, class_2338 b) {
      class_2680 s = lv.method_8320(b);
      if (!hazardState(s) && s.method_26227().method_15769()) {
         class_265 sh = s.method_26220(lv, b);
         return !sh.method_1110() && sh.method_1105(class_2351.field_11052) <= 1.0001;
      } else {
         return false;
      }
   }

   static boolean lavaNear(class_638 lv, class_2338 f) {
      if (AutoSandOrders.lavaAt(lv, f.method_10074())) {
         return true;
      } else {
         for (class_2350 d : AutoSandOrders.HORIZ) {
            class_2338 n = f.method_10093(d);
            if (AutoSandOrders.lavaAt(lv, n) || AutoSandOrders.lavaAt(lv, n.method_10084())) {
               return true;
            }
         }

         return false;
      }
   }

   static void expand(class_638 lv, class_2338 p, List<AutoMiner.Move> out) {
      class_2338 head2 = p.method_10086(2);

      for (class_2350 d : AutoSandOrders.HORIZ) {
         class_2338 n = p.method_10093(d);
         double c1 = cellCost(lv, n);
         double c2 = cellCost(lv, n.method_10084());
         if (c1 >= 0.0 && c2 >= 0.0) {
            if (!solidGround(lv, n.method_10074())) {
               if (c1 == 0.0 && c2 == 0.0) {
                  int fallMax = AutoSandOrders.avoidHole ? 2 : 3;

                  for (int k = 1; k <= fallMax; k++) {
                     class_2338 m = n.method_10087(k);
                     if (cellCost(lv, m) != 0.0) {
                        break;
                     }

                     if (solidGround(lv, m.method_10074())) {
                        if (!lavaNear(lv, m)) {
                           out.add(new AutoMiner.Move(m, 1.5 + 0.6 * k));
                        }
                        break;
                     }
                  }
               }
            } else {
               boolean cave = AutoSandOrders.avoidHole && AutoSandOrders.caveStep(lv, p, n, c1 == 0.0 && c2 == 0.0);
               if (!lavaNear(lv, n) && !cave) {
                  out.add(new AutoMiner.Move(n, 1.0 + c1 + c2));
               }
            }
         }

         if (solidGround(lv, n)) {
            class_2338 up = n.method_10084();
            double a = cellCost(lv, head2);
            double b = cellCost(lv, up);
            double c = cellCost(lv, up.method_10084());
            boolean cave = AutoSandOrders.avoidHole && AutoSandOrders.caveStep(lv, p, up, a == 0.0 && b == 0.0 && c == 0.0);
            if (a >= 0.0 && b >= 0.0 && c >= 0.0 && !lavaNear(lv, up) && !cave) {
               out.add(new AutoMiner.Move(up, 1.8 + a + b + c));
            }
         }
      }

      for (int i = 0; i < 4; i++) {
         class_2350 a = AutoSandOrders.HORIZ[i];
         class_2350 b = AutoSandOrders.HORIZ[(i + 1) % 4];
         class_2338 pa = p.method_10093(a);
         class_2338 pb = p.method_10093(b);
         class_2338 dn = pa.method_10093(b);
         if (cellCost(lv, pa) == 0.0
            && cellCost(lv, pa.method_10084()) == 0.0
            && cellCost(lv, pb) == 0.0
            && cellCost(lv, pb.method_10084()) == 0.0
            && cellCost(lv, dn) == 0.0
            && cellCost(lv, dn.method_10084()) == 0.0
            && solidGround(lv, pa.method_10074())
            && solidGround(lv, pb.method_10074())
            && solidGround(lv, dn.method_10074())
            && !lavaNear(lv, dn)) {
            out.add(new AutoMiner.Move(dn, 1.42));
         }
      }
   }

   static double heur(class_2338 n, class_243 t) {
      double dx = n.method_10263() + 0.5 - t.field_1352;
      double dz = n.method_10260() + 0.5 - t.field_1350;
      double dy = n.method_10264() - t.field_1351;
      return Math.sqrt(dx * dx + dz * dz) + Math.abs(dy) * 0.7;
   }

   static List<class_2338> findPath(class_638 lv, class_2338 start, class_243 target, Predicate<class_2338> goal, int maxNodes, boolean partial) {
      PriorityQueue<AutoMiner.Nd> open = new PriorityQueue<>(Comparator.comparingDouble(x -> x.f));
      Map<Long, Double> bestG = new HashMap<>();
      Set<Long> closed = new HashSet<>();
      AutoMiner.Nd s = new AutoMiner.Nd(start, null, 0.0, heur(start, target) * 1.3);
      open.add(s);
      bestG.put(start.method_10063(), 0.0);
      AutoMiner.Nd best = s;
      double bestH = heur(start, target);
      int expanded = 0;
      List<AutoMiner.Move> mv = new ArrayList<>();

      while (!open.isEmpty() && expanded < maxNodes) {
         AutoMiner.Nd cur = open.poll();
         if (closed.add(cur.pos.method_10063())) {
            expanded++;
            if (goal.test(cur.pos)) {
               return build(cur);
            }

            double h = heur(cur.pos, target);
            if (h < bestH) {
               bestH = h;
               best = cur;
            }

            mv.clear();
            expand(lv, cur.pos, mv);

            for (AutoMiner.Move m : mv) {
               class_2338 np = m.pos;
               if (Math.abs(np.method_10263() - start.method_10263()) <= 48 && Math.abs(np.method_10260() - start.method_10260()) <= 48) {
                  long k = np.method_10063();
                  if (!closed.contains(k)) {
                     double ng = cur.g + m.cost + (fluidAdj(lv, np) ? 12.0 : 0.0);
                     Double old = bestG.get(k);
                     if (old == null || !(old <= ng)) {
                        bestG.put(k, ng);
                        open.add(new AutoMiner.Nd(np, cur, ng, ng + heur(np, target) * 1.3));
                     }
                  }
               }
            }
         }
      }

      return partial && best != s ? build(best) : null;
   }

   static List<class_2338> build(AutoMiner.Nd end) {
      ArrayList<class_2338> r = new ArrayList<>();

      for (AutoMiner.Nd n = end; n.parent != null; n = n.parent) {
         r.add(n.pos);
      }

      Collections.reverse(r);
      return r;
   }

   static class_243 deathCenter() {
      return new class_243(deathPos.method_10263() + 0.5, deathPos.method_10264(), deathPos.method_10260() + 0.5);
   }

   static boolean pearlHpLow(class_310 mc, class_746 p, String what) {
      if (p.method_6032() >= 12.0F) {
         pearlHpWait = 0;
         hpEatTries = 0;
         hpEatCool = 0;
         return false;
      } else {
         if (++pearlHpWait == 1) {
            AutoSandOrders.msg(p, "Máu thấp (" + (int)p.method_6032() + "), chờ hồi máu rồi mới ném ngọc" + what + ".");
         }

         if (hpEatCool > 0) {
            hpEatCool--;
         } else if (hpEatTries < 3) {
            hpEatCool = 100;
            if (AutoSandOrders.healBeforePearl(mc, p)) {
               hpEatTries++;
            }
         }

         return true;
      }
   }

   static void tickRecovery(class_310 mc, class_746 p, class_638 lv) {
      if (deathPos != null && (rec == 5 || ++recTicks <= 9000)) {
         if (hasAnyShovel(p)) {
            gotShovel = true;
         }

         if (rec != 5 && rec != 1) {
            fixShovel(mc, p);
         }

         class_243 dc = deathCenter();
         switch (rec) {
            case 1:
               release(mc);
               if (--recTimer > 0) {
                  return;
               }

               if (kitDrop(mc, p)) {
                  recTimer = 3;
                  return;
               }

               if (homeCmd != null && !homeCmd.isBlank()) {
                  homeFrom = p.method_73189();
                  teleported = false;
                  AutoSandOrders.send(p, "/" + homeCmd);
                  homeTries++;
                  rec = 2;
                  recTimer = 200;
                  break;
               }

               rec = deathRecover ? 3 : 2;
               recTimer = deathRecover ? 0 : 200;
               path = null;
               return;
            case 2:
               release(mc);
               if (!teleported && homeFrom != null && p.method_73189().method_1025(homeFrom) > 16.0) {
                  teleported = true;
                  AutoSandOrders.msg(p, "Đã về home, đứng yên cho đủ 10 giây.");
               }

               if (--recTimer > 0) {
                  return;
               }

               double far = Math.hypot(p.method_23317() - dc.field_1352, p.method_23321() - dc.field_1350);
               if (!teleported && homeTries < 2 && far > 80.0 && homeCmd != null && !homeCmd.isBlank()) {
                  homeFrom = p.method_73189();
                  AutoSandOrders.send(p, "/" + homeCmd);
                  homeTries++;
                  recTimer = 200;
                  return;
               }

               if (!deathRecover) {
                  endRecovery(mc, p, "đã về home (tắt nhặt đồ)");
                  return;
               }

               AutoSandOrders.msg(p, "Đi tới chỗ chết.");
               rec = 3;
               recTimer = 20;
               path = null;
               break;
            case 3:
               if (recTimer > 0) {
                  recTimer--;
                  release(mc);
                  return;
               }

               if (deathDim != null && !deathDim.equals(lv.method_27983())) {
                  endRecovery(mc, p, "đang ở chiều không gian khác với chỗ chết");
                  return;
               }

               double hd = Math.hypot(p.method_23317() - dc.field_1352, p.method_23321() - dc.field_1350);
               if (hd <= 3.0 && Math.abs(p.method_23318() - dc.field_1351) <= 4.0) {
                  release(mc);
                  rec = 4;
                  collectIdle = 0;
                  collectTicks = 0;
                  itemWait = 0;
                  itemTarget = null;
                  path = null;
                  AutoSandOrders.msg(p, "Tới chỗ chết, bắt đầu nhặt đồ.");
                  return;
               }

               if (AutoSandOrders.usePearl && !pearlDone && hd > 60.0) {
                  rec = 6;
                  pearlThrows = 0;
                  pearlStep = 0;
                  pearlTimer = 0;
                  pearlHpWait = 0;
                  hpEatTries = 0;
                  hpEatCool = 0;
                  return;
               }

               if (recTicks % 100 == 0) {
                  double d = p.method_73189().method_1022(dc);
                  if (d > walkBest - 2.0) {
                     walkNoProg++;
                  } else {
                     walkNoProg = 0;
                  }

                  walkBest = Math.min(walkBest, d);
                  if (walkNoProg >= 6 || walkFails > 12) {
                     endRecovery(mc, p, "không đi tới được toạ độ chết");
                     return;
                  }
               }

               if (crossCool > 0) {
                  crossCool--;
               }

               if (path == null || pi >= path.size()) {
                  path = null;
                  List<class_2338> rp = findPath(
                     lv,
                     p.method_24515(),
                     dc,
                     q -> Math.hypot(q.method_10263() + 0.5 - dc.field_1352, q.method_10260() + 0.5 - dc.field_1350) <= 2.5 && Math.abs(q.method_10264() - dc.field_1351) <= 3.0,
                     6000,
                     true
                  );
                  boolean noWay = rp == null || rp.isEmpty();
                  boolean detour = !noWay && rp.size() > hd * 2.0 + 20.0;
                  if ((noWay || detour) && tryCross(mc, p, lv, dc)) {
                     return;
                  }

                  if (noWay) {
                     if (++blindTicks > 600) {
                        endRecovery(mc, p, "không tìm được đường tới chỗ chết");
                        return;
                     }

                     blindWalk(mc, p, dc);
                     return;
                  }

                  path = rp;
                  pi = 0;
                  stuck = 0;
               }

               int r = followPath(mc, p, lv);
               if (r == 2) {
                  path = null;
                  stuck = 0;
                  walkFails++;
                  if (walkFails >= 2 && tryCross(mc, p, lv, dc)) {
                     return;
                  }
               } else if (r == 1) {
                  path = null;
               }
               break;
            case 4:
               if (++collectTicks > 2400) {
                  orgWhy = null;
                  toOrganize(mc);
                  return;
               }

               if (itemTarget == null || itemTarget.method_31481()) {
                  itemTarget = findDrop(lv, p, dc, hasAnyShovel(p) ? 12.0 : 24.0, false);
                  path = null;
                  itemWait = 0;
                  if (itemTarget == null) {
                     release(mc);
                     if (++collectIdle >= (hasAnyShovel(p) ? 60 : 200)) {
                        orgWhy = null;
                        toOrganize(mc);
                     }

                     return;
                  }

                  collectIdle = 0;
               }

               class_1542 it = itemTarget;
               class_243 ip = it.method_73189();
               if (path == null) {
                  itemPlanPos = ip;
                  List<class_2338> rp = findPath(
                     lv,
                     p.method_24515(),
                     ip,
                     q -> Math.hypot(q.method_10263() + 0.5 - ip.field_1352, q.method_10260() + 0.5 - ip.field_1350) < 0.9 && Math.abs(q.method_10264() - ip.field_1351) < 2.0,
                     2500,
                     false
                  );
                  if (rp == null) {
                     ignoreItems.add(it.method_5628());
                     itemTarget = null;
                     return;
                  }

                  path = rp;
                  pi = 0;
                  stuck = 0;
               }

               int r2 = followPath(mc, p, lv);
               if (r2 == 2) {
                  ignoreItems.add(it.method_5628());
                  itemTarget = null;
                  path = null;
                  release(mc);
               } else if (r2 == 1) {
                  release(mc);
                  if (itemPlanPos != null && ip.method_1025(itemPlanPos) > 2.25) {
                     path = null;
                     itemWait = 0;
                     return;
                  }

                  if (++itemWait > 50) {
                     ignoreItems.add(it.method_5628());
                     itemTarget = null;
                     path = null;
                  }
               }
               break;
            case 5:
               release(mc);
               if (--recTimer > 0) {
                  return;
               }

               if (recStep++ > 40) {
                  endRecovery(mc, p, orgWhy);
                  return;
               }

               if (organize(mc, p)) {
                  recTimer = 4;
               } else {
                  endRecovery(mc, p, orgWhy);
               }
               break;
            case 6:
               release(mc);
               if (deathDim != null && !deathDim.equals(lv.method_27983())) {
                  pearlDone = true;
                  rec = 3;
                  path = null;
                  return;
               }

               double hdx = Math.hypot(p.method_23317() - dc.field_1352, p.method_23321() - dc.field_1350);
               if (hdx <= 12.0 || pearlThrows >= 4) {
                  pearlDone = true;
                  rec = 3;
                  recTimer = 0;
                  path = null;
                  return;
               }

               if (pearlTimer > 0) {
                  pearlTimer--;
                  return;
               }

               if (pearlHpLow(mc, p, "")) {
                  if (pearlHpWait > 600) {
                     AutoSandOrders.msg(p, "Máu vẫn thấp sau 30 giây, đi bộ tới chỗ chết.");
                     pearlDone = true;
                     rec = 3;
                     path = null;
                  }

                  return;
               }

               int pi2x = AutoSandOrders.findItem(p, class_1802.field_8634);
               if (pi2x < 0) {
                  if (pearlBuyFails >= 2) {
                     AutoSandOrders.msg(p, "Không mua được ngọc Ender, đi bộ tới chỗ chết.");
                     pearlDone = true;
                     rec = 3;
                     path = null;
                     return;
                  }

                  int need = (int)Math.min((double)(4 - pearlThrows), Math.ceil(hdx / 45.0));
                  AutoSandOrders.beginPearlBuy(mc, p, Math.max(1, need));
                  pearlTimer = 10;
                  return;
               }

               switch (pearlStep) {
                  case 0:
                     int slot = AutoSandOrders.toHotbar(mc, p, pi2x);
                     AutoSandOrders.setSelected(p, slot);
                     class_243 eye = p.method_33571();
                     double dx = dc.field_1352 - eye.field_1352;
                     double dz = dc.field_1350 - eye.field_1350;
                     double dxx = Math.hypot(dx, dz);
                     class_243 aim = dxx <= 45.0 ? new class_243(dc.field_1352, dc.field_1351, dc.field_1350) : new class_243(eye.field_1352 + dx / dxx * 45.0, p.method_23318(), eye.field_1350 + dz / dxx * 45.0);
                     float[] ang = solvePearl(lv, p, aim);
                     if (ang == null) {
                        AutoSandOrders.msg(p, "Không tính được đường ném ngọc, đi bộ tới chỗ chết.");
                        pearlDone = true;
                        rec = 3;
                        path = null;
                        return;
                     }

                     pearlYaw = ang[0];
                     pearlPitch = ang[1];
                     p.method_36456(pearlYaw);
                     p.method_36457(pearlPitch);
                     pearlStep = 1;
                     pearlTimer = 4;
                     return;
                  case 1:
                     p.method_36456(pearlYaw);
                     p.method_36457(pearlPitch);
                     mc.field_1761.method_2919(p, class_1268.field_5808);
                     p.method_6104(class_1268.field_5808);
                     pearlThrows++;
                     pearlStep = 0;
                     pearlTimer = 60;
                     return;
                  default:
                     pearlStep = 0;
                     return;
               }
            case 7:
               release(mc);
               if (pearlTimer > 0) {
                  pearlTimer--;
                  return;
               }

               if (crossStep == 0) {
                  if (pearlHpLow(mc, p, " qua nước")) {
                     if (pearlHpWait > 600) {
                        crossCool = 600;
                        rec = 3;
                        path = null;
                     }

                     return;
                  }

                  int pi2 = AutoSandOrders.findItem(p, class_1802.field_8634);
                  if (pi2 < 0) {
                     if (pearlBuyFails >= 2) {
                        AutoSandOrders.msg(p, "Không mua được ngọc Ender để qua nước, thử đi vòng.");
                        crossCool = 1200;
                        rec = 3;
                        path = null;
                        return;
                     }

                     AutoSandOrders.beginPearlBuy(mc, p, 1);
                     pearlTimer = 10;
                     return;
                  }

                  float[] ang = planCross(lv, p, dc);
                  if (ang == null) {
                     AutoSandOrders.msg(p, "Không tìm được chỗ đáp ngọc bên kia nước, thử đi vòng.");
                     crossCool = 400;
                     rec = 3;
                     path = null;
                     return;
                  }

                  AutoSandOrders.setSelected(p, AutoSandOrders.toHotbar(mc, p, pi2));
                  pearlYaw = ang[0];
                  pearlPitch = ang[1];
                  p.method_36456(pearlYaw);
                  p.method_36457(pearlPitch);
                  crossFrom = p.method_73189();
                  crossStep = 1;
                  pearlTimer = 4;
               } else if (crossStep == 1) {
                  p.method_36456(pearlYaw);
                  p.method_36457(pearlPitch);
                  mc.field_1761.method_2919(p, class_1268.field_5808);
                  p.method_6104(class_1268.field_5808);
                  crossThrows++;
                  crossStep = 2;
                  pearlTimer = 50;
               } else {
                  boolean moved = crossFrom != null && p.method_73189().method_1022(crossFrom) > 4.0;
                  AutoSandOrders.msg(p, moved ? "Đã qua nước bằng ngọc Ender." : "Ngọc chưa dịch chuyển được, thử lại / đi vòng.");
                  crossStep = 0;
                  crossCool = moved ? 40 : 200;
                  rec = 3;
                  path = null;
                  stuck = 0;
                  walkFails = 0;
                  blindTicks = 0;
                  walkNoProg = 0;
                  walkBest = Double.MAX_VALUE;
               }
               break;
            default:
               rec = 0;
         }
      } else {
         endRecovery(mc, p, "quá thời gian, bỏ qua");
      }
   }

   static void toOrganize(class_310 mc) {
      orgDone = true;
      release(mc);
      rec = 5;
      recStep = 0;
      recTimer = 5;
      path = null;
      itemTarget = null;
   }

   static void blindWalk(class_310 mc, class_746 p, class_243 t) {
      double dx = t.field_1352 - p.method_23317();
      double dz = t.field_1350 - p.method_23321();
      p.method_36456((float)Math.toDegrees(Math.atan2(-dx, dz)));
      p.method_36457(0.0F);
      mc.field_1690.field_1894.method_23481(true);
      mc.field_1690.field_1903.method_23481(p.field_5976 && p.method_24828());
   }

   static void endRecovery(class_310 mc, class_746 p, String why) {
      if (!orgDone) {
         orgDone = true;
         orgWhy = why;
         toOrganize(mc);
      } else {
         orgDone = false;
         rec = 0;
         deathRecorded = false;
         deathMarker = false;
         gotShovel = false;
         release(mc);
         path = null;
         itemTarget = null;
         target = null;
         ph = 0;
         scanCool = 0;
         baseY = p.method_24515().method_10264();
         ignoreItems.clear();
         AutoSandOrders.junkCool = 0;
         if (!hasAnyShovel(p)) {
            AutoSandOrders.msg(p, (why == null ? "Đã nhặt xong đồ" : "Dừng nhặt đồ: " + why) + " nhưng không có xẻng nào trong người. Tắt AutoSand.");
            AutoSandOrders.setEnabled(mc, false);
         } else {
            active = true;
            if (AutoSandOrders.useNuker) {
               AutoSandOrders.setNuker(p, true);
            }

            AutoSandOrders.msg(p, (why == null ? "Đã nhặt xong đồ, xếp lại thanh công cụ." : "Dừng nhặt đồ: " + why + ".") + " Đào tiếp.");
         }
      }
   }

   static int hotbarShovel(class_746 p) {
      for (int i = 0; i < 9; i++) {
         if (p.method_31548().method_5438(i).method_31573(class_3489.field_42615)) {
            return i;
         }
      }

      return -1;
   }

   static int bestShovelInBackpack(class_746 p) {
      int best = -1;
      double bp = -1.0;

      for (int i = 9; i < 36; i++) {
         class_1799 st = p.method_31548().method_5438(i);
         if (!st.method_7960() && st.method_31573(class_3489.field_42615)) {
            double pct = AutoSandOrders.remainingPct(st);
            if (pct > bp) {
               bp = pct;
               best = i;
            }
         }
      }

      return best;
   }

   static int prefShovelSlot() {
      for (int i = 0; i < 9; i++) {
         if (snapShovel[i]) {
            return i;
         }
      }

      return 0;
   }

   static int freeHotbar(class_746 p, int pref) {
      if (p.method_31548().method_5438(pref).method_7960()) {
         return pref;
      } else {
         for (int i = 0; i < 9; i++) {
            if (p.method_31548().method_5438(i).method_7960()) {
               return i;
            }
         }

         return pref;
      }
   }

   static boolean organize(class_310 mc, class_746 p) {
      if (p.method_6079().method_31573(class_3489.field_42615)) {
         AutoSandOrders.swapOffhand(mc, p, freeHotbar(p, 0));
         return true;
      } else {
         int[] mv = AutoSandOrders.arrangeMove(p);
         if (mv != null) {
            AutoSandOrders.swapHotbar(mc, p, mv[0], mv[1]);
            return true;
         } else {
            if (hotbarShovel(p) < 0 && !shovelWarned) {
               shovelWarned = true;
               AutoSandOrders.msg(p, "Không tìm thấy xẻng nào để đặt lại thanh công cụ.");
            }

            int hs = hotbarShovel(p);
            if (hs >= 0 && AutoSandOrders.getSelected(p) != hs) {
               AutoSandOrders.setSelected(p, hs);
               return true;
            } else {
               return false;
            }
         }
      }
   }

   static boolean isKit(class_1799 st) {
      return !st.method_7960() && !st.method_31573(class_3489.field_42615)
         ? st.method_31573(class_3489.field_42614)
            || st.method_31573(class_3489.field_42611)
            || st.method_31574(class_1802.field_8229)
            || st.method_31573(class_3489.field_48297)
            || st.method_31573(class_3489.field_48296)
            || st.method_31573(class_3489.field_48295)
            || st.method_31573(class_3489.field_48294)
         : false;
   }

   static int kitSlot(class_746 p) {
      for (int i = 5; i <= 8; i++) {
         if (!p.field_7498.method_7611(i).method_7677().method_7960()) {
            return i;
         }
      }

      for (int ix = 0; ix < 36; ix++) {
         if (isKit(p.method_31548().method_5438(ix))) {
            return AutoSandOrders.menuSlot(ix);
         }
      }

      return isKit(p.method_6079()) ? 45 : -1;
   }

   static boolean kitDrop(class_310 mc, class_746 p) {
      if (kitStep >= 2) {
         return false;
      } else {
         int slot = kitSlot(p);
         if (kitStep == 0) {
            if (slot < 0) {
               kitStep = 2;
               return false;
            } else {
               kitXRot = p.method_36455();
               p.method_36457(0.0F);
               kitStep = 1;
               return true;
            }
         } else if (slot >= 0 && kitDropped < 40) {
            mc.field_1761.method_2906(p.field_7498.field_7763, slot, 1, class_1713.field_7795, p);
            kitDropped++;
            return true;
         } else {
            if (!Float.isNaN(kitXRot)) {
               p.method_36457(kitXRot);
               kitXRot = Float.NaN;
            }

            kitStep = 2;
            AutoSandOrders.msg(p, "Đã vứt " + kitDropped + " món (giáp, cúp, kiếm, bánh mì) trước khi về home.");
            return false;
         }
      }
   }

   static void fixShovel(class_310 mc, class_746 p) {
      if (++fixCool >= 20) {
         fixCool = 0;
         if (hotbarShovel(p) < 0) {
            if (p.method_6079().method_31573(class_3489.field_42615)) {
               AutoSandOrders.swapOffhand(mc, p, freeHotbar(p, 0));
            } else {
               int idx = bestShovelInBackpack(p);
               if (idx >= 9) {
                  AutoSandOrders.swapHotbar(mc, p, idx, freeHotbar(p, 0));
               }
            }
         }
      }
   }

   static boolean hasAnyShovel(class_746 p) {
      if (p.method_6079().method_31573(class_3489.field_42615)) {
         return true;
      } else {
         for (int i = 0; i < 36; i++) {
            if (p.method_31548().method_5438(i).method_31573(class_3489.field_42615)) {
               return true;
            }
         }

         return false;
      }
   }

   static void arrowTick(class_310 mc, class_746 p) {
      if (deathMarker && deathPos != null && !p.method_29504() && mc.field_1687 != null) {
         if (deathDim == null || deathDim.equals(mc.field_1687.method_27983())) {
            if (++arrowCnt % 10 == 0) {
               double dx = deathPos.method_10263() + 0.5 - p.method_23317();
               double dz = deathPos.method_10260() + 0.5 - p.method_23321();
               double hd = Math.hypot(dx, dz);
               if (hd < 4.0 && Math.abs(p.method_23318() - deathPos.method_10264()) < 8.0) {
                  deathMarker = false;
               } else {
                  double rel = Math.toDegrees(Math.atan2(-dx, dz)) - p.method_36454();
                  rel = ((rel + 180.0) % 360.0 + 360.0) % 360.0 - 180.0;
                  int idx = (int)Math.floorMod(Math.round(rel / 45.0), 8L);
                  mc.field_1705.method_1758(class_2561.method_43470(ARROWS[idx] + "  Chỗ chết: " + lastDeathText + "  -  còn " + (int)hd + " ô"), false);
               }
            }
         }
      }
   }

   static boolean waterAhead(class_638 lv, class_746 p, class_243 dc) {
      double dx = dc.field_1352 - p.method_23317();
      double dz = dc.field_1350 - p.method_23321();
      double d = Math.hypot(dx, dz);
      if (d < 3.0) {
         return false;
      } else {
         dx /= d;
         dz /= d;
         int py = p.method_24515().method_10264();

         for (int k = 1; k <= 12; k++) {
            for (int dy = -2; dy <= 1; dy++) {
               if (AutoSandOrders.liquidAt(lv, class_2338.method_49637(p.method_23317() + dx * k, py + dy, p.method_23321() + dz * k))) {
                  return true;
               }
            }
         }

         return false;
      }
   }

   static boolean tryCross(class_310 mc, class_746 p, class_638 lv, class_243 dc) {
      if (!AutoSandOrders.usePearl || crossThrows >= 4 || crossCool > 0) {
         return false;
      } else if (p.method_5799() || p.method_5771() || !p.method_24828()) {
         return false;
      } else if (!waterAhead(lv, p, dc)) {
         return false;
      } else {
         AutoSandOrders.msg(p, "Có nước chắn đường tới chỗ chết -> ném ngọc Ender sang bên kia.");
         rec = 7;
         crossStep = 0;
         pearlTimer = 0;
         pearlHpWait = 0;
         path = null;
         release(mc);
         return true;
      }
   }

   static boolean dryLanding(class_638 lv, class_2338 f) {
      if (AutoSandOrders.walkable(lv, f) && !AutoSandOrders.liquidAt(lv, f) && !AutoSandOrders.liquidAt(lv, f.method_10084())) {
         int land = 0;

         for (class_2350 h : AutoSandOrders.HORIZ) {
            class_2338 n = f.method_10093(h);
            if (AutoSandOrders.walkable(lv, n) && !AutoSandOrders.liquidAt(lv, n)) {
               land++;
            }
         }

         return land >= 2;
      } else {
         return false;
      }
   }

   static float[] planCross(class_638 lv, class_746 p, class_243 dc) {
      class_243 eye = p.method_33571();
      double base = Math.toDegrees(Math.atan2(-(dc.field_1352 - p.method_23317()), dc.field_1350 - p.method_23321()));
      int py = p.method_24515().method_10264();
      List<class_2338> cands = new ArrayList<>();

      for (double off : new double[]{0.0, 12.0, -12.0, 25.0, -25.0, 40.0, -40.0}) {
         double r = Math.toRadians(base + off);
         double ux = -Math.sin(r);
         double uz = Math.cos(r);
         boolean sawWater = false;

         for (int k = 2; k <= 30; k++) {
            double x = p.method_23317() + ux * k;
            double z = p.method_23321() + uz * k;
            class_2338 found = null;
            boolean wet = false;

            for (int dy = 2; dy >= -3; dy--) {
               class_2338 f = class_2338.method_49637(x, py + dy, z);
               if (AutoSandOrders.liquidAt(lv, f)) {
                  wet = true;
               }

               if (found == null && dryLanding(lv, f)) {
                  found = f;
               }
            }

            if (wet && found == null) {
               sawWater = true;
            }

            if (sawWater && found != null) {
               class_2338 best = found;

               for (int m = 1; m <= 2; m++) {
                  class_2338 g = class_2338.method_49637(x + ux * m, found.method_10264(), z + uz * m);
                  if (dryLanding(lv, g)) {
                     best = g;
                  }
               }

               cands.add(best);
               break;
            }
         }
      }

      cands.sort(Comparator.comparingDouble(b -> Math.hypot(b.method_10263() + 0.5 - dc.field_1352, b.method_10260() + 0.5 - dc.field_1350)));

      for (class_2338 c : cands) {
         class_243 aim = new class_243(c.method_10263() + 0.5, c.method_10264(), c.method_10260() + 0.5);
         float[] ang = solvePearl(lv, p, aim);
         if (ang != null) {
            class_243 h = simPearlHit(lv, p, eye, ang[0], ang[1]);
            if (h != null) {
               class_2338 lc = class_2338.method_49637(h.field_1352, h.field_1351 + 0.05, h.field_1350);
               if (!(Math.hypot(h.field_1352 - aim.field_1352, h.field_1350 - aim.field_1350) > 3.0)
                  && AutoSandOrders.passable(lv, lc)
                  && AutoSandOrders.passable(lv, lc.method_10084())
                  && !AutoSandOrders.liquidAt(lv, lc)
                  && !AutoSandOrders.liquidAt(lv, lc.method_10084())) {
                  return ang;
               }
            }
         }
      }

      return null;
   }

   static double[] simPearl(class_638 lv, class_746 p, class_243 eye, float yaw, float pitch) {
      double yr = Math.toRadians(yaw);
      double pr = Math.toRadians(pitch);
      double cp = Math.cos(pr);
      double vx = -Math.sin(yr) * cp * 1.5;
      double vy = -Math.sin(pr) * 1.5;
      double vz = Math.cos(yr) * cp * 1.5;
      class_243 pos = new class_243(eye.field_1352, eye.field_1351 - 0.1, eye.field_1350);

      for (int t = 0; t < 160; t++) {
         class_243 next = new class_243(pos.field_1352 + vx, pos.field_1351 + vy, pos.field_1350 + vz);
         class_3965 r = lv.method_17742(new class_3959(pos, next, net.minecraft.class_3959.class_3960.field_17558, class_242.field_1348, p));
         if (r.method_17783() == class_240.field_1332) {
            class_243 h = r.method_17784();
            return new double[]{Math.hypot(h.field_1352 - eye.field_1352, h.field_1350 - eye.field_1350), h.field_1351};
         }

         pos = next;
         vx *= 0.99;
         vy = vy * 0.99 - 0.03;
         vz *= 0.99;
         if (next.field_1351 < -70.0) {
            return null;
         }
      }

      return null;
   }

   static class_243 simPearlHit(class_638 lv, class_746 p, class_243 eye, float yaw, float pitch) {
      double yr = Math.toRadians(yaw);
      double pr = Math.toRadians(pitch);
      double cp = Math.cos(pr);
      double vx = -Math.sin(yr) * cp * 1.5;
      double vy = -Math.sin(pr) * 1.5;
      double vz = Math.cos(yr) * cp * 1.5;
      class_243 pos = new class_243(eye.field_1352, eye.field_1351 - 0.1, eye.field_1350);

      for (int t = 0; t < 160; t++) {
         class_243 next = new class_243(pos.field_1352 + vx, pos.field_1351 + vy, pos.field_1350 + vz);
         class_3965 r = lv.method_17742(new class_3959(pos, next, net.minecraft.class_3959.class_3960.field_17558, class_242.field_1348, p));
         if (r.method_17783() == class_240.field_1332) {
            return r.method_17784();
         }

         pos = next;
         vx *= 0.99;
         vy = vy * 0.99 - 0.03;
         vz *= 0.99;
         if (next.field_1351 < -70.0) {
            return null;
         }
      }

      return null;
   }

   static float[] solvePearl(class_638 lv, class_746 p, class_243 target) {
      class_243 eye = p.method_33571();
      double dx = target.field_1352 - eye.field_1352;
      double dz = target.field_1350 - eye.field_1350;
      double want = Math.hypot(dx, dz);
      float yaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
      float best = Float.NaN;
      double bestErr = 1.0E9;

      for (float pitch = 10.0F; pitch >= -85.0F; pitch -= 0.5F) {
         double[] r = simPearl(lv, p, eye, yaw, pitch);
         if (r != null) {
            double err = Math.abs(r[0] - want) + Math.abs(r[1] - target.field_1351) * 0.2;
            if (err < bestErr - 0.01) {
               bestErr = err;
               best = pitch;
            }
         }
      }

      return !Float.isNaN(best) && !(bestErr > 6.0) ? new float[]{yaw, best} : null;
   }

   static final class Cand {
      final class_2338 pos;
      final double score;

      Cand(class_2338 pos, double score) {
         this.pos = pos;
         this.score = score;
      }
   }

   static final class Move {
      final class_2338 pos;
      final double cost;

      Move(class_2338 pos, double cost) {
         this.pos = pos;
         this.cost = cost;
      }
   }

   static final class Nd {
      final class_2338 pos;
      final AutoMiner.Nd parent;
      final double g;
      final double f;

      Nd(class_2338 pos, AutoMiner.Nd parent, double g, double f) {
         this.pos = pos;
         this.parent = parent;
         this.g = g;
         this.f = f;
      }
   }
}
